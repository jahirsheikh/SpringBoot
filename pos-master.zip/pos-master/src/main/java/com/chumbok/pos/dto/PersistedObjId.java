package com.chumbok.pos.dto;

public class PersistedObjId {

    private long id;

    public PersistedObjId(long id){
        this.id = id;
    }

    public long getId() {
        return id;
    }
}
