package com.geekster.weeklyTest.project.RestaurantManagementApplication.Model.Enums;

public enum FoodType {
    Starter, HotBeverage, ColdBeverage, MainCourse, Breads, Desert
}
