package com.geekster.project.RestaurantManagementServiceAPI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestaurantManagementServiceApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
