package com.geekster.project.RestaurantManagementServiceAPI;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestaurantManagementServiceApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestaurantManagementServiceApiApplication.class, args);
	}

}
