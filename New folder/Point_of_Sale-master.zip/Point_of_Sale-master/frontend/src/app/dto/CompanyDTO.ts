export interface CompanyDTO {
    id: number,
    name: string,
    mobile: string,
    email: string,
    address: string
}