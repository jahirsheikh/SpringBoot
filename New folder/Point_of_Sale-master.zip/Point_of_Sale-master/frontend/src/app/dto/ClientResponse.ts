export interface ClientResponse {
    success: boolean
    message: string
}

