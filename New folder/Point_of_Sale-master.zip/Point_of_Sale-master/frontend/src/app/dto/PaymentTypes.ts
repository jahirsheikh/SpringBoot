export enum PaymentTypes {
    Cash = "CASH",
    Cheque = "CHEQUE",
    Credit_Card = "CREDIT_CARD",
}