export interface UserDto {
    id: number;
    name: string;
    mobile: string;
    email: string;
    createdAt: string;
    role: string;
    isEnabled: boolean;
}
