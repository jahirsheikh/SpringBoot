export interface LoginResponse {
    token: string;
    success: boolean;
    message: string;
}
