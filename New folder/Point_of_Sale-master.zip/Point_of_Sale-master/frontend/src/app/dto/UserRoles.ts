export enum UserRoles {
    USER = "ROLE_USER",
    ADMIN = "ROLE_ADMIN"
}
