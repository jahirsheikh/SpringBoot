import {CompanyDTO} from "./CompanyDTO";

export interface SupplierDTO {
    name: string,
    mobile: string,
    email: string,
    company: number,
}