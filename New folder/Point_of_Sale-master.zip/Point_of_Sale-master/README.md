Hello! This is one of my final project submitted in IsDB-BISEW.

Ive used SpringBoot for backend and Angular for forntend.

Took the help of my faculty the project is mostly done except for the dashbord and some buttons. Will Complete it Soon.

Just Download the project Use "npm i" for anguler then use "ng serve" command the forntend will up and running i've used angular15. I will also attach a db file soon for some startup data.
