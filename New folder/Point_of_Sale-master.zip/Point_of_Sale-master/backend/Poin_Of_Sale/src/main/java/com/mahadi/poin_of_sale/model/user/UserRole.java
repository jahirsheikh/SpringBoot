package com.mahadi.poin_of_sale.model.user;

public enum UserRole {
    ROLE_USER,
    ROLE_ADMIN
}
