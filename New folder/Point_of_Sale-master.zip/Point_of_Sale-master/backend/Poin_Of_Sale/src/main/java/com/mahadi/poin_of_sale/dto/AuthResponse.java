package com.mahadi.poin_of_sale.dto;

public record AuthResponse(String token, boolean success, String message) {
}
