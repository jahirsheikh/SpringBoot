package com.mahadi.poin_of_sale.model.grn;


public enum PaymentType {
    CASH,
    CREDIT_CARD,
    CHEQUE
}
