package com.mahadi.poin_of_sale.dto;

public record StockUpdateDTO(
        Long stockId,
        Double newPrice
)
{
}
