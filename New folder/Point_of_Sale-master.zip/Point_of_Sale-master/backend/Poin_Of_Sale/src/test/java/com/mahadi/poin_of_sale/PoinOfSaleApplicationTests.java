package com.mahadi.poin_of_sale;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PoinOfSaleApplicationTests {

	@Test
	void contextLoads() {
	}

}
