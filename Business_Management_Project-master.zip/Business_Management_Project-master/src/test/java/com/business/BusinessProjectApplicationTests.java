package com.business;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BusinessProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
