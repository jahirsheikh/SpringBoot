package com.jahir.project_daynamic_pos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectDaynamicPosApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjectDaynamicPosApplication.class, args);
	}

}
