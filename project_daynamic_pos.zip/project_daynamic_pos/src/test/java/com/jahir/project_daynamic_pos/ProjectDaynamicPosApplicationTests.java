package com.jahir.project_daynamic_pos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectDaynamicPosApplicationTests {

	@Test
	void contextLoads() {
	}

}
