import { DepartmentModel } from "./department.model";

export class Employee {
    id?: number;
    name?: string;
    email?: string;
    gender?: string;
    eCellNo?: string;
    dob?: Date;
    image?: string;
    department?: {
        id: number;  // Ensure this property is present
        dname: string;
      };
  }