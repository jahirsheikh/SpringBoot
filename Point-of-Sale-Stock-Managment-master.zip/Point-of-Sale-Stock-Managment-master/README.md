# Point-of-Sale-Stock-Managment
This was my first project using java, Swing and MySql
