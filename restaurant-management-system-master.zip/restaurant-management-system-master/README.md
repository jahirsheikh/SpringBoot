# Restaurant Management System
Developing this for my school as first final year project. It shall be able to handle most of the challanges that encountered while managing a restaurant like table management, menu management etc. The project is designed as a web application with Rest API and database connectivity (PostreSQL).
