package com.tahadonuk.restaurantmanagementsystem.dto.stat;

import lombok.Data;

@Data
public abstract class Stats {
    private long totalCount;
}
