package com.tahadonuk.restaurantmanagementsystem.exception;

public class ItemNotFoundException extends NotFoundException{
    public ItemNotFoundException(String message) {
        super(message);
    }
}
