package com.tahadonuk.restaurantmanagementsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestaurantManagementSystemApplicationTests {

    @Test
    void contextLoads() {
    }

}
